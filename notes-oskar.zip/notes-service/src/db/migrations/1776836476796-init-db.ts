import { MigrationInterface, QueryRunner } from "typeorm";

export class InitDb1776836476796 implements MigrationInterface {
	async up(queryRunner: QueryRunner): Promise<void> {
		await queryRunner.query(`CREATE TABLE "Note" (
			"id" UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
			"color" CHARACTER VARYING(255) NULL,
			"text" TEXT NOT NULL,
			"title" TEXT NOT NULL
		)`);
	}

	async down(queryRunner: QueryRunner): Promise<void> {
		await queryRunner.query(`DROP TABLE "Note"`);
	}
}
