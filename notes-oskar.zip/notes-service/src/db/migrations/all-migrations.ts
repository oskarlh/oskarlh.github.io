import { InitDb1776836476796 } from "./1776836476796-init-db.ts";

export const migrations = [InitDb1776836476796];
