import { Note } from "./note.entity.ts";

export const entities = [Note];
