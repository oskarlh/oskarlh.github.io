import type { UUID } from "node:crypto";
import { Entity, Column, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Note {
	@PrimaryGeneratedColumn("uuid")
	id!: UUID;

	@Column("character varying", {
		default: "",
		nullable: true,
		length: 255,
	})
	color?: null | string;

	@Column("text", {
		default: "",
	})
	text!: string;

	@Column("text", {
		default: "",
	})
	title!: string;

	@UpdateDateColumn()
	updatedDate!: Date;
}
