import { DataSource } from "typeorm";
import { migrations } from "./migrations/all-migrations.ts";
import { entities } from "./entities/all-entities.ts";

export const dataSource = new DataSource({
	type: "postgres",
	host: process.env.POSTGRES_HOST || "localhost",
	port: Number(process.env.POSTGRES_POST) || 5432,
	username: process.env.POSTGRES_USER || "user",
	password: process.env.POSTGRES_PASSWORD || "password",
	database: process.env.POSTGRES_DB || "notes",
	entities,
	synchronize: true,
	migrations,
});
