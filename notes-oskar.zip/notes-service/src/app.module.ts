import { Module } from "@nestjs/common";

import { NotesModule } from "./notes/notes.module.ts";
import { TypeOrmModule } from "@nestjs/typeorm";
import { dataSource } from "./db/data-source.ts";

@Module({
	imports: [TypeOrmModule.forRoot(dataSource.options), NotesModule],
	controllers: [],
	providers: [],
})
export class AppModule {}
