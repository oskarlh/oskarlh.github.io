import { NestFactory } from "@nestjs/core";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import { AppModule } from "./app.module";
import { ValidationPipe } from "@nestjs/common";

async function bootstrap() {
	const app = await NestFactory.create(AppModule, { cors: true });

	// Set up API documentation available at /api and /api-json
	const config = new DocumentBuilder().setTitle("Notes API").setVersion("1.0").build();
	const documentFactory = () =>
		SwaggerModule.createDocument(app, config, {
			operationIdFactory: (_controllerKey, methodKey, version = "") => `${methodKey}${version}`,
		});
	SwaggerModule.setup("api", app, documentFactory);

	// Validate payloads
	app.useGlobalPipes(
		new ValidationPipe({
			forbidNonWhitelisted: true,
			whitelist: true,
		}),
	);

	await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
