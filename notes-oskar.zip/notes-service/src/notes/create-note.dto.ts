import { ApiPropertyOptional } from "@nestjs/swagger";
import { IsOptional, IsString } from "class-validator";

export class CreateNoteDto {
	@IsOptional()
	@IsString()
	@ApiPropertyOptional({
		example: "#FFFF00",
	})
	color?: null | string;

	@IsOptional()
	@IsString()
	text?: string;

	@IsOptional()
	@IsString()
	title?: string;
}
