import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";

import { NotesController } from "./notes.controller.js";
import { NotesService } from "./notes.service.js";
import { Note } from "../db/entities/note.entity.js";

@Module({
	imports: [TypeOrmModule.forFeature([Note])],
	controllers: [NotesController],
	providers: [NotesService],
})
export class NotesModule {}
