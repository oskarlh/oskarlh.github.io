import {
	Body,
	Controller,
	Delete,
	Get,
	NotFoundException,
	Param,
	Patch,
	Post,
} from "@nestjs/common";
import { NotesService } from "./notes.service";
import { Note } from "../db/entities/note.entity.ts";
import {
	ApiCreatedResponse,
	ApiNoContentResponse,
	ApiNotFoundResponse,
	ApiOkResponse,
} from "@nestjs/swagger";
import { CreateNoteDto } from "./create-note.dto.ts";
import { UpdateNoteDto } from "./update-note.dto.ts";
import type { UUID } from "node:crypto";

@Controller("/notes")
export class NotesController {
	constructor(private readonly notesService: NotesService) {}

	@Post()
	@ApiCreatedResponse({ description: "Success", type: Note })
	async createNote(@Body() createNoteDto: CreateNoteDto): Promise<Note> {
		return await this.notesService.createNote(createNoteDto);
	}

	@Delete(":id")
	@ApiNoContentResponse({ description: "Success" })
	@ApiNotFoundResponse({ description: "The Note could note be found" })
	async deleteNote(@Param("id") id: UUID): Promise<void> {
		if (!(await this.notesService.deleteNote(id))) {
			throw new NotFoundException("There is no Note with that ID");
		}
	}

	@Get()
	@ApiOkResponse({ type: [Note] })
	async getNotes(): Promise<Note[]> {
		return this.notesService.getNotes();
	}

	@Patch(":id")
	@ApiNoContentResponse({ description: "Success" })
	@ApiNotFoundResponse({ description: "The Note could note be found" })
	async updateNote(@Param("id") id: UUID, @Body() updateNoteDto: UpdateNoteDto): Promise<void> {
		if (!(await this.notesService.updateNote(id, updateNoteDto))) {
			throw new NotFoundException("There is no Note with that ID");
		}
	}
}
