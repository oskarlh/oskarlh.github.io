import { Injectable, OnModuleInit } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Note } from "../db/entities/note.entity.ts";
import { Repository } from "typeorm";
import type { UUID } from "node:crypto";
import { CreateNoteDto } from "./create-note.dto.ts";
import { UpdateNoteDto } from "./update-note.dto.ts";

@Injectable()
export class NotesService implements OnModuleInit {
	constructor(
		@InjectRepository(Note)
		private notesRepository: Repository<Note>,
	) {}

	/**
	 * Create a new Note
	 */
	async createNote(createNoteDto: CreateNoteDto): Promise<Note> {
		return await this.notesRepository.save(createNoteDto);
	}

	/**
	 * Deletes a Note
	 * @returns `true` if the Note was found and deleted, `false` if the Note was not found
	 */
	async deleteNote(id: UUID): Promise<boolean> {
		return Boolean((await this.notesRepository.delete({ id })).affected);
	}

	/**
	 * Gets all Notes - most recently updated first
	 */
	async getNotes(): Promise<Note[]> {
		return this.notesRepository.find({ order: { updatedDate: "DESC" } });
	}

	/**
	 * Updates an existing Note
	 * @returns `true` if the Note was found and updated, `false` if the Note was not found
	 */
	async updateNote(id: UUID, updateNoteDto: UpdateNoteDto): Promise<boolean> {
		return Boolean((await this.notesRepository.update(id, updateNoteDto)).affected);
	}

	async onModuleInit() {
		// A bit of an ugly hack... add an empty note if the user hasn't made one yet
		if ((await this.getNotes()).length === 0) {
			await this.createNote({});
		}
	}
}
