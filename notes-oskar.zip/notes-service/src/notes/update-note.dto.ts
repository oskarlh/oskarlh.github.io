import { CreateNoteDto } from "./create-note.dto.ts";

export class UpdateNoteDto extends CreateNoteDto {}
