import { defineConfig } from "@hey-api/openapi-ts";

export default defineConfig([
	{
		input: "http://localhost:3000/api-json",
		output: {
			importFileExtension: "ts",
			path: "src/apis/notes/generatedClient",
			postProcess: ["prettier"],
		},
		plugins: [
			"@hey-api/typescript",
			{
				name: "@hey-api/client-fetch",
				throwOnError: true,
			},
			{
				dates: true,
				name: "@hey-api/transformers",
			},
			{
				auth: true,
				examples: true,
				name: "@hey-api/sdk",
				transformer: true,
				operations: {
					containerName: "NotesApiClient",
					strategy: "single",
				},
			},
		],
	},
]);
