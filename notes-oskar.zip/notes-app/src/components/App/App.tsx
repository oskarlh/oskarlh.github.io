import { NotesList } from "../NotesList/NotesList.tsx";
import { ErrorBoundary } from "react-error-boundary";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient();

export function App() {
	return (
		<QueryClientProvider client={queryClient}>
			<main>
				<h1>Notes</h1>
				<ErrorBoundary fallback={<p>Something went wrong</p>}>
					<NotesList />
				</ErrorBoundary>
			</main>
		</QueryClientProvider>
	);
}
