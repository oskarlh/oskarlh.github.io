import styled from "styled-components";
import { useNotes } from "../../data/useNotes.ts";
import { NoteEditor } from "../NoteEditor/NoteEditor.tsx";
import { useCreateNote } from "../../data/useCreateNote.ts";

export function NotesList() {
	const { notes, notesPending, refetchNotes } = useNotes();
	const { createNote, creatingNote } = useCreateNote();

	const handleNewNoteButtonClick = async () => {
		await createNote();
		await refetchNotes();
	};

	return (
		<Container>
			{notesPending && <p>Loading notes…</p>}
			<NewNoteButton onClick={handleNewNoteButtonClick} disabled={creatingNote || notesPending}>
				Make a new note
			</NewNoteButton>
			{notes?.map((note) => (
				<NoteEditor note={note} key={note.id} onDeleted={refetchNotes} />
			))}
		</Container>
	);
}

const Container = styled.section`
	display: flex;
	flex-direction: column;
	gap: 1em;
`;

const NewNoteButton = styled.button`
	align-content: center;
	display: inline-flex;
	gap: 0.75ch;
	padding-inline: 1ch;
	width: 20ch;
`;
