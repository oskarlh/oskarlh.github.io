import { useRef, type ChangeEvent } from "react";
import { ColorPickerIcon } from "../../icons/ColorPickerIcon.tsx";
import styled from "styled-components";

export interface ColorPickerButtonProps {
	className?: string;
	color?: string;
	defaultColor?: string;
	onChange: (color: string) => void;
}

export function ColorPickerButton({ className, color, onChange }: ColorPickerButtonProps) {
	const inputRef = useRef<HTMLInputElement>(null);

	const handleChange = ({ target: { value } }: ChangeEvent<HTMLInputElement>) => {
		onChange(value);
	};
	const handleClick = () => {
		inputRef.current?.showPicker();
	};

	return (
		<Button className={className} onClick={handleClick} title="Pick color">
			<Icon />
			<input type="color" value={color} hidden onChange={handleChange} ref={inputRef} />
		</Button>
	);
}

const Button = styled.button`
	align-content: center;
	display: inline-flex;
	gap: 0.75ch;
	padding-inline: 1ch;
`;

const Icon = styled(ColorPickerIcon)`
	margin: auto;
	vertical-align: middle;
`;
