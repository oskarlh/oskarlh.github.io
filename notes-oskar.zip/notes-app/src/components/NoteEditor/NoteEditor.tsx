import { useState, type ChangeEvent } from "react";
import { DeleteIcon } from "../../icons/DeleteIcon.tsx";
import {
	ColorButton,
	Container,
	DeleteButton,
	SaveIndicator,
	TextArea,
	TitleInput,
} from "./styledNoteEditorComponents.ts";
import type { Note } from "../../apis/notes/generatedClient/types.gen.ts";
import { useDeleteNote } from "../../data/useDeleteNote.ts";
import { useUpdateNote } from "../../data/useUpdateNote.ts";

export interface NoteEditorProps {
	note: Note;
	onDeleted: () => void;
}

const defaultColorPickerColor = "#F4C501";

export function NoteEditor({ note, onDeleted }: NoteEditorProps) {
	const [color, setColor] = useState(note.color ?? undefined);
	const [text, setText] = useState(note.text);
	const [title, setTitle] = useState(note.title);

	const { deleteNote, deletingNote } = useDeleteNote();
	const { updateNote, updatingNote } = useUpdateNote();

	const handleColorChange = (value: string) => {
		setColor(value);
		updateNote({ color: value, id: note.id });
	};

	const handleTextChange = ({ target: { value } }: ChangeEvent<HTMLTextAreaElement>) => {
		setText(value);
		updateNote({ text: value, id: note.id });
	};

	const handleTitleChange = ({ target: { value } }: ChangeEvent<HTMLInputElement>) => {
		setTitle(value);
		updateNote({ title: value, id: note.id });
	};

	const handleDelete = async () => {
		await deleteNote(note.id);
		onDeleted();
	};

	return (
		<Container color={color} disable={deletingNote}>
			<TitleInput type="text" placeholder="Title" value={title} onChange={handleTitleChange} />
			<TextArea placeholder="Make a note…" value={text} onChange={handleTextChange} />
			<div>
				<DeleteButton title="Delete" onClick={handleDelete}>
					<DeleteIcon />
				</DeleteButton>
				<ColorButton
					color={color}
					defaultColor={defaultColorPickerColor}
					onChange={handleColorChange}
				/>
				<SaveIndicator hidden={updatingNote}>Saving…</SaveIndicator>
			</div>
		</Container>
	);
}
