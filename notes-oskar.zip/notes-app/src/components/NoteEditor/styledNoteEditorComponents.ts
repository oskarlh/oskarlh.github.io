import styled from "styled-components";
import { ColorPickerButton } from "../ColorPickerButton/ColorPickerButton.tsx";

export const Container = styled.div<{
	color?: string;
	disable?: boolean;
}>`
	${({ color }) =>
		color &&
		`
		background: ${color};
		color: contrast-color(${color});
		@supports not (color: contrast-color(${color})) {
			color: black;
		}
	`}
	border: 2px solid;
	border-radius: 8px;

	${({ disable }) =>
		disable
			? `
		filter: blur(5px);
		pointer-events: none;
	`
			: ""}

	transition: filter 0.5s ease-out;
`;

export const ColorButton = styled(ColorPickerButton)`
	height: 32px;
`;

export const DeleteButton = styled.button`
	margin: 0;
	padding: 0;
	height: 32px;
	width: 32px;
	align-content: center;
	display: inline-flex;
	& > svg {
		margin: auto;
	}
`;

export const SaveIndicator = styled.p`
	&:not([hidden]) {
		display: inline-block;
	}
	margin-block: 0;
	margin-inline: 1ch;
	opacity: 0.5;
`;

export const TextArea = styled.textarea`
	display: block;
	background: none;
	border: none;
	outline: none;
	margin: 0;
	padding: 1ch;
	font-size: 1em;
	width: 100%;
	resize: none;
	field-sizing: content;
	box-sizing: border-box;
	color: inherit;

	/* Mozilla wants to implement field-sizing by the end of 2026, so set a fixed height for Firefox users */
	@supports not (field-sizing: content) {
		&:not(:placeholder-shown) {
			height: 15lh;
		}
	}
	&::placeholder {
		color: inherit;
	}
`;

export const TitleInput = styled.input`
	display: block;
	width: 100%;
	border: none;
	margin: 0;
	padding: 1ch;
	font-size: 1em;
	background: none;
	box-sizing: border-box;
	outline: none;
	font-weight: bold;
	color: inherit;
	&::placeholder {
		color: inherit;
	}
`;
