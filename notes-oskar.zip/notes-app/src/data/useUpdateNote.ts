import { useMutation } from "@tanstack/react-query";
import { notesApiClient } from "../apis/notes/notesApiClient.ts";

export function useUpdateNote() {
	const { isPending, mutateAsync } = useMutation({
		mutationFn: ({
			id,
			...body
		}: {
			id: string;
			color?: null | string;
			text?: string;
			title?: string;
		}) => notesApiClient.updateNote({ path: { id }, body }),
		throwOnError: true,
	});

	return { updatingNote: isPending, updateNote: mutateAsync };
}
