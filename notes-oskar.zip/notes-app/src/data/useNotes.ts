import { useQuery } from "@tanstack/react-query";
import { notesApiClient } from "../apis/notes/notesApiClient.ts";

export function useNotes() {
	const { data, isPending, refetch } = useQuery({
		queryKey: ["notes"],
		queryFn: async () => (await notesApiClient.getNotes()).data,
		throwOnError: true,
	});

	return { notes: data, notesPending: isPending, refetchNotes: refetch };
}
