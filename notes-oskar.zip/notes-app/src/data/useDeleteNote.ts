import { useMutation } from "@tanstack/react-query";
import { notesApiClient } from "../apis/notes/notesApiClient.ts";

export function useDeleteNote() {
	const { isPending, mutateAsync } = useMutation({
		mutationFn: (id: string) => notesApiClient.deleteNote({ path: { id } }),
		throwOnError: true,
	});

	return { deletingNote: isPending, deleteNote: mutateAsync };
}
