import { useMutation } from "@tanstack/react-query";
import { notesApiClient } from "../apis/notes/notesApiClient.ts";

export function useCreateNote() {
	const { isPending, mutateAsync } = useMutation({
		mutationFn: () => notesApiClient.createNote({ body: {} }),
		throwOnError: true,
	});

	return { creatingNote: isPending, createNote: mutateAsync };
}
