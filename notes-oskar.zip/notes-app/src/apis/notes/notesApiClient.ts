import { createClient } from "./generatedClient/client/client.gen.ts";
import { NotesApiClient } from "./generatedClient/sdk.gen.ts";

export const notesApiClient = new NotesApiClient({
	client: createClient({
		baseUrl: "http://localhost:3000/",
		throwOnError: true as const,
	}),
});
