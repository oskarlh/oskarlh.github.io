# Different ways to implement `abs()`
These should work fine for any `x` where `typeof x === "number"` including `NaN`, `Infinity`, `-Infinity`, and `-0`:
```
const abs = (x: number) => Math.sign(x) * x;
```

```
const abs = (x: number) => x >= 0 ? (x || 0) : -x;
```

```
const abs = (x: number) => Math.max(x, -x);
```

```
const abs = (x: number) => -Math.min(x, -x);
```

```
const abs = (x: number) => [x, -x].toSorted()[1];
```

```
const abs = (x: number) => String(x).startsWith("-") ? -x : x;
```

```
function abs(x: number) {
    if(!Math.isFinite(x)) {
        return Infinity;
    }

    return Math.max(Number(String(x).substring(1)), x);
}
```

I learned this bit-flipping technique when working on [a little math library](https://github.com/oskarlh/cmath-js) of JavaScript versions of C math functions and I used something similar to implement `nan()`:
```
function abs(x: number) {
    const dataView = new DataView(new ArrayBuffer(8));
    dataView.setFloat64(0, x);
    dataView.setUint8(0, dataView.getUint8(0) & 0b0111_1111); // Zero the sign bit
    return dataView.getFloat64(0);
}
```

Rounding errors are possible with this:
```
const abs = (x: number) => Math.sqrt(x * x);
```

This is only reliable when `Math.trunc(x)` is a valid 32-bit integer:

```
function abs(x: number) {
    if(x === -0) {
        return 0;
    }
    if(Math.clz32(x) === 0) {
        return -x;
    }
    return x;
}
```

This only works with integers and the special values:
```
function abs(x: number) {
  if(x & (1 << 31) || !x) {
    return ~x + 1;
  }

  return x;
}
```

This does not work with `NaN` or `Infinity` due to limitations in the math service:
```
async function abs(x: number) {
    const mathEndpoint = new URL("https://api.mathjs.org/v4/");
    mathEndpoint.searchParams.set("expr", `abs(${x})`);
    return (await fetch(mathEndpoint)).json();
}
```
