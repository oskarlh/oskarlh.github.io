Hi and thank you for reviewing my submission!

Please note that the "notes-app" project is built using the React Compiler, eliminating the need for `useMemo` and `useCallback`.

To start the app, run `docker compose up` in this folder and open http://localhost:5173/ in your browser

- Oskar
