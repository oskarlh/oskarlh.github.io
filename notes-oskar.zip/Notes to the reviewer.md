Hi and thank you for reviewing my submission!

Please note that the "notes-app" project is built using the React Compiler, eliminating the need for `useMemo` and `useCallback`.

To get started, run `docker compose up` and open http://localhost:5173/ in your browser

- Oskar
